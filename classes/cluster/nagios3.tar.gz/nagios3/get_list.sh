#!/bin/bash

services="./service.lst"
while IFS=' ' read -r service port
do
echo "define service {
  use upgrade_service_tpl

  register 1
  service_description $service
  host_name upg_ctl
  check_command check_os_service!10.109.1.10!$port

}"
done < "$services"
